/* sfun_getSystemClockTimeval.c - a simple s-function to report system time
 * using the POSIX command gettimeofday().
 *
 * It works in Simulink in Windows and compiles as a stand-alone executable
 * in Windows/Cygwin and linux/unix.
 *
 * Compile at the Matlab command line with:
 *   mex sfun_getSystemClockTimeval.c
 *
 * Marc Compere
 * comperem@gmail.com
 * created : 21 Apr 2005
 * modified: 28 May 2018
 *
 * Copyright 2005-2018 Marc Compere
 * Copyright 1990-2002 The MathWorks, Inc.
 * $Revision: 1.27 $
 */

#define S_FUNCTION_NAME  sfun_getSystemClockTimeval
#define S_FUNCTION_LEVEL 2

#include "simstruc.h"

#include <stdio.h>
#include <sys/time.h>
#include <time.h>



/* make a user-defined SLEEP() function that calls   */
/* Windows Sleep() or linux usleep() at compile time */
#ifdef WIN32
  #include "windows.h" // for call to Sleep()
  #define SLEEP(x) Sleep(x) /* for Win32, argument is in milliseconds */
#else
  #include <unistd.h> /* for usleep(), argument is in microseconds */
  #define SLEEP(x) usleep(1000*x) /* for unix,linux */
#endif





/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    /* See sfuntmpl_doc.c for more details on the macros below */

    ssSetNumSFcnParams(S, 0);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        /* Return if number of expected != number of actual parameters */
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    if (!ssSetNumInputPorts(S, 0)) return;
    
    if (!ssSetNumOutputPorts(S, 3)) return;
    ssSetOutputPortWidth(S, 0, 1); // seconds since January 1st, 1970 
    ssSetOutputPortWidth(S, 1, 1); // microseconds associated with seconds since January 1st, 1970 
    ssSetOutputPortWidth(S, 2, 1); // combined seconds and microseconds since January 1st, 1970    

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 0);
    ssSetNumPWork(S, 0);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    ssSetOptions(S, 0);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    This function is used to specify the sample time(s) for your
 *    S-function. You must register the same number of sample times as
 *    specified in ssSetNumSampleTimes.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    //ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);

}



#define MDL_INITIALIZE_CONDITIONS   /* Change to #undef to remove function */
#if defined(MDL_INITIALIZE_CONDITIONS)
  /* Function: mdlInitializeConditions ========================================
   * Abstract:
   *    In this function, you should initialize the continuous and discrete
   *    states for your S-function block.  The initial states are placed
   *    in the state vector, ssGetContStates(S) or ssGetRealDiscStates(S).
   *    You can also perform any other initialization activities that your
   *    S-function may require. Note, this routine will be called at the
   *    start of simulation and if it is present in an enabled subsystem
   *    configured to reset states, it will be call when the enabled subsystem
   *    restarts execution to reset the states.
   */
  static void mdlInitializeConditions(SimStruct *S)
  {
  }
#endif /* MDL_INITIALIZE_CONDITIONS */



#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START) 
  /* Function: mdlStart =======================================================
   * Abstract:
   *    This function is called once at start of model execution. If you
   *    have states that should be initialized once, this is the place
   *    to do it.
   */
  static void mdlStart(SimStruct *S)
  {
  }
#endif /*  MDL_START */



/* Function: mdlOutputs =======================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block. Generally outputs are placed in the output vector, ssGetY(S).
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    real_T  *y0 = ssGetOutputPortRealSignal(S,0); // seconds since January 1st, 1970
    real_T  *y1 = ssGetOutputPortRealSignal(S,1); // microseconds associated with seconds since January 1st, 1970
    real_T  *y2 = ssGetOutputPortRealSignal(S,2); // combined seconds and microseconds since January 1st, 1970
    
    /* The POSIX command gettimeofday() populates a timeval struct defined as:
     *
     *      struct timeval {
     *          time_t      tv_sec;     // seconds
     *          suseconds_t tv_usec;    // microseconds
     *      };
     *
     * gettimeofday() requires #include <sys/time.h>
     *
     * Marc Compere, comperem@gmail.com
     * 15 Dec 2015
     */

    struct timeval tv; // declare a timeval struct

    gettimeofday(&tv, (struct timezone *) 0); /* populate timeval struct */

    y0[0] = (double) tv.tv_sec;  /* output integer seconds since Jan 01, 1970 */
    y1[0] = (double) tv.tv_usec; /* output microseconds */
    y2[0] = (double) tv.tv_sec+(tv.tv_usec/1.0e6); /* output combined seconds since Jan 01, 1970 */

}



#define MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
  }
#endif /* MDL_UPDATE */



#define MDL_DERIVATIVES  /* Change to #undef to remove function */
#if defined(MDL_DERIVATIVES)
  /* Function: mdlDerivatives =================================================
   * Abstract:
   *    In this function, you compute the S-function block's derivatives.
   *    The derivatives are placed in the derivative vector, ssGetdX(S).
   */
  static void mdlDerivatives(SimStruct *S)
  {
  }
#endif /* MDL_DERIVATIVES */



/* Function: mdlTerminate =====================================================
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was
 *    allocated in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
}


/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
